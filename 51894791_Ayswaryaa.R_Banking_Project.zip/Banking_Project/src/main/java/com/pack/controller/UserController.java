package com.pack.controller;

import java.sql.SQLException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.pack.model.Account;
import com.pack.model.Customer;
import com.pack.model.User;
import com.pack.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;
 
	
	@RequestMapping("Login")
	public String add(Model m)
	{
		
		m.addAttribute("userBean", new User());
		return "login";
	}
	
	
	@RequestMapping(value="/verify", method = RequestMethod.POST)
	public String validate(@Valid @ModelAttribute("userBean")User userBean,BindingResult result,Model m)throws Exception
	{
		String r=userService.validate(userBean);
		 if (r.equals("success"))
			 {
	
			  return "welcome";
			 }
	 else
	 {
		m.addAttribute("user", userBean);
  		return "failure";		
	}
	}
	@RequestMapping("create")
	public String create(Model m)
	{
		m.addAttribute("cusBean",new Customer());
		return "createPage";
		
	}
	@RequestMapping(value="/create", method = RequestMethod.POST)
	public String customer(@Valid @ModelAttribute("cusBean")Customer c,Account a,BindingResult result,Model m)throws Exception
	{
		 if (result.hasErrors())
			 {
	
			  return "createPage";
			 }
	 else
	 {
		 long x=userService.customer(c, a);
		m.addAttribute("account", x);
		m.addAttribute("id",c.getCustId());  		  
	    return "last";		
		
	}
	}
	
	
	
	}


