package com.pack.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Random;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;

import com.pack.model.Account;
import com.pack.model.Customer;
import com.pack.model.User;

public class UserDao {
	
	@Autowired
	private	 SessionFactory sessionFactory;
	
	public String validate(User userBean) throws Exception
	{
		Session session = sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		System.out.println("DAO class");
		String q="from User where uname=:un and pwd=:pass";
		Query que=session.createQuery(q);
		que.setParameter("un",userBean.getUname());
		que.setParameter("pass",userBean.getPwd());
		List<String> x=que.getResultList();
		/*int k=0;
		for(String y:x)
		{
			if(y==userBean.getPwd())
				k=1;
		}*/
		if((x!=null)&&(x.size()>0))
			return "welcome";
		else
			System.out.println("DAO else clause");
			return "failure";
		
	}
	public long customer(Customer c,Account a)
	{
		Random x=new Random();
		Session s=sessionFactory.openSession();
		Transaction t=s.beginTransaction();
		long y=(long)x.nextInt(10000000);
		Long z=(long)x.nextInt(100000000);
		String acc_no=z.toString();
		c.setCustId(y);
		a.setAccNo(Long.parseLong(acc_no));
		a.getAccType();
		long o=(long) s.save(a);
		t.commit();
		s.close();
		return o;
		
		
	}
	 
	
	
	}


