package com.pack.service;


import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;

import com.pack.dao.UserDao;
import com.pack.model.*;

public class UserService {
	
	@Autowired
	private UserDao userDAO;

		public String validate(User userBean)throws Exception
		{
			//userDAO.validatee(userBean);
			System.out.println("Entered service class");
			String s=userDAO.validate(userBean);
			return s;
			
		}
		public long customer(Customer c,Account a)throws Exception
		{
			long i=userDAO.customer(c, a);
			return i;
		}
		
		
		
}
